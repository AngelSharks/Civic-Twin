=== Civic_twin_Angel_Sharks_wp.V.0.1 (City of Santa Barbara, CA Demo) ===
Contributors: Angel Sharks
Donate link: https://angelsharks.net
Tags: santa barbara, civic twin, digital twin, gis, smart city, leaflet, mesh, b-lan
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.2
Stable tag: 0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Dedicated WordPress Digital Twin Demo Plugin for the City of Santa Barbara, CA (https://santabarbaraca.gov/) by Angel Sharks. Requires PHP 8.2 or higher.

== Description ==

This demo WordPress plugin provides a turnkey digital twin integration specifically calibrated for the **City of Santa Barbara, CA** (official website: [santabarbaraca.gov](https://santabarbaraca.gov/)).

It empowers municipal webmasters and community administrators to embed real-time NIST urban resilience indicators, high-resolution Leaflet GIS overlays (Mission Creek watershed, State Street corridor, coastal marine zones), and B-LAN mesh network telemetry into any WordPress installation.

### Key Features:
* **PHP 8.2+ Architecture:** Built with strict typing and modern WordPress coding standards.
* **Pre-Calibrated Santa Barbara Centroid:** Configured for Santa Barbara, California (34.4208° N, -119.6982° W) and official municipal portal https://santabarbaraca.gov/.
* **Automatic Page Generator:** Scaffolds demo pages for `/santa-barbara-digital-twin`, `/santa-barbara-gis-map`, and `/santa-barbara-community-portal` in one click.
* **Responsive Shortcodes:** Embed interactive twins, full GIS maps, or municipal cards into any page, post, or block.

== Installation ==

1. Download `Civic_twin_Angel_Sharks_wp.V.0.1.zip`.
2. Ensure your WordPress hosting server is running **PHP 8.2 or higher**.
3. In WordPress Admin, navigate to **Plugins > Add New > Upload Plugin**.
4. Select `Civic_twin_Angel_Sharks_wp.V.0.1.zip` and click **Install Now**.
5. Click **Activate Plugin**.
6. Navigate to **SB Civic Twin** in your WordPress sidebar to review settings and run diagnostics.

== Shortcodes ==

* `[civic_twin_dashboard]` - Embeds the full Santa Barbara interactive Digital Twin matrix.
* `[civic_twin_map]` - Embeds the Santa Barbara Leaflet GIS map with coastal hydrology and transit layers.
* `[civic_twin_member_portal]` - Embeds the Santa Barbara Community Identity & emergency B-LAN portal.
* `[civic_twin_sb_info]` - Displays the official City of Santa Barbara municipal info badge linked to https://santabarbaraca.gov/.

== Changelog ==

= 0.1 =
* Initial dedicated demo fork for the City of Santa Barbara, CA (https://santabarbaraca.gov/).
* Enforced PHP 8.2+ minimum runtime.
* Automated page generator for Santa Barbara portals.

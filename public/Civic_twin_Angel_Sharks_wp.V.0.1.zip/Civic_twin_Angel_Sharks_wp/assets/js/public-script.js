/**
 * Civic_Twin Santa Barbara Public Script (PHP 8.2+)
 * Handles interactive Native Leaflet GIS mapping, hydrology sliders, and B-LAN mesh simulation.
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        initSantaBarbaraNativeTwin();
        initSantaBarbaraStandaloneMap();
        initMemberPortalBroadcast();
    });

    /**
     * Initialize Native Santa Barbara Digital Twin Matrix
     */
    function initSantaBarbaraNativeTwin() {
        var mapContainer = document.getElementById('ct-sb-leaflet-map');
        if (!mapContainer || typeof L === 'undefined') {
            return;
        }

        // Get coordinates from localized options or defaults
        var lat = (typeof civicTwinSBOptions !== 'undefined' && civicTwinSBOptions.cityLat) ? civicTwinSBOptions.cityLat : 34.42083;
        var lng = (typeof civicTwinSBOptions !== 'undefined' && civicTwinSBOptions.cityLng) ? civicTwinSBOptions.cityLng : -119.69819;

        // Initialize Leaflet Map
        var map = L.map('ct-sb-leaflet-map', {
            center: [lat, lng],
            zoom: 13,
            zoomControl: true,
            attributionControl: true
        });

        // Tile layer (CartoDB Voyager raster tiles for modern high-contrast cartography)
        L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/">CARTO</a> | City of Santa Barbara, CA',
            maxZoom: 19,
            subdomains: 'abcd'
        }).addTo(map);

        // Layer Groups
        var watershedsLayer = L.layerGroup();
        var meshLayer = L.layerGroup();
        var transitLayer = L.layerGroup();

        // 1. Mission Creek Watershed Basin (Santa Barbara Front Country)
        var missionCreekCoords = [
            [34.460, -119.725],
            [34.455, -119.705],
            [34.440, -119.690],
            [34.425, -119.688],
            [34.415, -119.692],
            [34.411, -119.695],
            [34.420, -119.720],
            [34.445, -119.735]
        ];

        var missionCreekPolygon = L.polygon(missionCreekCoords, {
            color: '#0284c7',
            fillColor: '#38bdf8',
            fillOpacity: 0.35,
            weight: 2
        }).addTo(watershedsLayer);

        missionCreekPolygon.bindPopup(
            '<div style="font-family:sans-serif; font-size:12px;">' +
            '<h4 style="margin:0 0 4px 0; color:#0f172a;">💧 Mission Creek Watershed</h4>' +
            '<strong>Basin Extent:</strong> 11.5 sq mi<br/>' +
            '<strong>Discharge Capacity:</strong> 48.0 m³/s<br/>' +
            '<strong>Runoff Soil Infiltration:</strong> 64%<br/>' +
            '<a href="https://santabarbaraca.gov/" target="_blank" style="color:#0284c7;font-weight:bold;">Municipal Watershed Docs ↗</a>' +
            '</div>'
        );

        // Arroyo Burro Basin
        var arroyoBurroCoords = [
            [34.445, -119.760],
            [34.430, -119.740],
            [34.412, -119.742],
            [34.402, -119.745],
            [34.403, -119.758],
            [34.425, -119.770]
        ];

        var arroyoBurroPolygon = L.polygon(arroyoBurroCoords, {
            color: '#059669',
            fillColor: '#10b981',
            fillOpacity: 0.25,
            weight: 2
        }).addTo(watershedsLayer);

        arroyoBurroPolygon.bindPopup(
            '<div style="font-family:sans-serif; font-size:12px;">' +
            '<h4 style="margin:0 0 4px 0; color:#0f172a;">💧 Arroyo Burro Basin</h4>' +
            '<strong>Coastal Runoff:</strong> Hendry\'s Beach Outflow<br/>' +
            '<strong>Catchment Area:</strong> 9.2 sq mi' +
            '</div>'
        );

        // Waterfront & Stearns Wharf Marine Zone
        var marineCoords = [
            [34.415, -119.698],
            [34.412, -119.684],
            [34.401, -119.688],
            [34.404, -119.702]
        ];

        var marinePolygon = L.polygon(marineCoords, {
            color: '#2563eb',
            fillColor: '#60a5fa',
            fillOpacity: 0.25,
            weight: 2,
            dashArray: '5, 5'
        }).addTo(watershedsLayer);

        marinePolygon.bindPopup(
            '<div style="font-family:sans-serif; font-size:12px;">' +
            '<h4 style="margin:0 0 4px 0; color:#0f172a;">⚓ Santa Barbara Waterfront & Harbor</h4>' +
            'Stearns Wharf Coastal Zone • Storm Surge Monitoring' +
            '</div>'
        );

        // 2. B-LAN Emergency Mesh Nodes
        var nodes = [
            {
                name: 'City Hall Primary (Root Node)',
                coords: [34.42083, -119.69819],
                address: '735 Anacapa St',
                role: 'Gateway / Root Server'
            },
            {
                name: 'Cottage Hospital Emergency Node',
                coords: [34.4345, -119.7198],
                address: 'Pueblo St',
                role: 'Trauma Center Relay'
            },
            {
                name: 'Harbor Waterfront Patrol Node',
                coords: [34.4072, -119.6928],
                address: 'Cabrillo Blvd',
                role: 'Coastal Wave & Surge Monitor'
            },
            {
                name: 'SB Airport Corridor Link',
                coords: [34.4262, -119.8400],
                address: 'Hollister Ave',
                role: 'West Gateway Relay'
            }
        ];

        var nodeMarkers = [];
        nodes.forEach(function(node) {
            var iconHtml = '<div style="background:#0284c7; color:#fff; width:26px; height:26px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid #fff; box-shadow:0 0 10px rgba(2,132,199,0.7); font-size:12px;">📡</div>';
            var customIcon = L.divIcon({
                html: iconHtml,
                className: 'ct-custom-mesh-pin',
                iconSize: [26, 26],
                iconAnchor: [13, 13]
            });

            var marker = L.marker(node.coords, { icon: customIcon }).addTo(meshLayer);
            marker.bindPopup(
                '<div style="font-family:sans-serif; font-size:12px;">' +
                '<strong style="color:#0284c7;">' + node.name + '</strong><br/>' +
                '<strong>Location:</strong> ' + node.address + '<br/>' +
                '<strong>Role:</strong> ' + node.role + '<br/>' +
                '<strong>Status:</strong> <span style="color:#10b981;font-weight:bold;">Online (915.2 MHz)</span>' +
                '</div>'
            );
            nodeMarkers.push(marker);
        });

        // Connect nodes with wireless mesh topology lines
        var cityHall = [34.42083, -119.69819];
        var meshConnections = [
            [cityHall, [34.4345, -119.7198]],
            [cityHall, [34.4072, -119.6928]],
            [cityHall, [34.4262, -119.8400]],
            [[34.4345, -119.7198], [34.4072, -119.6928]]
        ];

        meshConnections.forEach(function(pts) {
            L.polyline(pts, {
                color: '#38bdf8',
                weight: 1.5,
                dashArray: '4, 6',
                opacity: 0.8
            }).addTo(meshLayer);
        });

        // 3. Transit & Evacuation Corridors
        var stateStreet = [
            [34.442, -119.728],
            [34.433, -119.715],
            [34.424, -119.702],
            [34.416, -119.695],
            [34.411, -119.688]
        ];

        L.polyline(stateStreet, {
            color: '#f59e0b',
            weight: 4,
            opacity: 0.85
        }).addTo(transitLayer).bindPopup('<strong>State Street Pedestrian & Cultural Corridor</strong>');

        var us101 = [
            [34.438, -119.760],
            [34.428, -119.730],
            [34.420, -119.695],
            [34.418, -119.670]
        ];

        L.polyline(us101, {
            color: '#6366f1',
            weight: 4,
            opacity: 0.85
        }).addTo(transitLayer).bindPopup('<strong>US-101 Coastal Transit Artery</strong><br/>Primary Regional Evacuation Route');

        // Add all layer groups to map initially
        watershedsLayer.addTo(map);
        meshLayer.addTo(map);
        transitLayer.addTo(map);

        // Layer Filter Buttons
        $('.ct-layer-btn').on('click', function() {
            var $btn = $(this);
            var layerName = $btn.data('layer');

            if (layerName === 'all') {
                $('.ct-layer-btn').addClass('active');
                if (!map.hasLayer(watershedsLayer)) map.addLayer(watershedsLayer);
                if (!map.hasLayer(meshLayer)) map.addLayer(meshLayer);
                if (!map.hasLayer(transitLayer)) map.addLayer(transitLayer);
                return;
            }

            $btn.toggleClass('active');
            var isActive = $btn.hasClass('active');

            if (layerName === 'watersheds') {
                if (isActive) map.addLayer(watershedsLayer); else map.removeLayer(watershedsLayer);
            } else if (layerName === 'mesh') {
                if (isActive) map.addLayer(meshLayer); else map.removeLayer(meshLayer);
            } else if (layerName === 'transit') {
                if (isActive) map.addLayer(transitLayer); else map.removeLayer(transitLayer);
            }
        });

        // Recenter button
        $('#ct-btn-recenter').on('click', function() {
            map.setView([lat, lng], 13, { animate: true });
        });

        // Fullscreen toggle
        $('#ct-btn-toggle-fullscreen').on('click', function() {
            var $wrap = $('#ct-sb-twin-root');
            $wrap.toggleClass('ct-fullscreen-active');
            if ($wrap.hasClass('ct-fullscreen-active')) {
                $wrap.css({
                    position: 'fixed',
                    top: '0',
                    left: '0',
                    width: '100vw',
                    height: '100vh',
                    zIndex: '99999',
                    margin: '0'
                });
                $(this).text('✖ Exit Fullscreen');
            } else {
                $wrap.removeAttr('style');
                $(this).text('⛶ Fullscreen');
            }
            setTimeout(function() { map.invalidateSize(); }, 300);
        });

        // Hydrology Simulation Interactive Sliders
        var $sliderRain = $('#ct-slider-rainfall');
        var $sliderSurge = $('#ct-slider-surge');

        function updateHydrologySim() {
            var rain = parseFloat($sliderRain.val()) || 0;
            var surge = parseFloat($sliderSurge.val()) || 0;

            $('#ct-label-rainfall').text(rain + ' mm/hr');
            $('#ct-label-surge').text(surge.toFixed(1) + ' m');

            // Rational runoff equation simulation: Q = C * I * A
            var discharge = (0.62 * rain * 0.95 + 1.2).toFixed(1);
            var saturation = Math.min(99, Math.round(45 + rain * 0.45));

            $('#ct-val-discharge').text(discharge);
            $('#ct-val-saturation').text(saturation);

            var $threatBadge = $('#ct-threat-badge');
            var $statusDischarge = $('#ct-status-discharge');
            var polyColor = '#0284c7';
            var polyFill = '#38bdf8';

            if (rain < 35) {
                $threatBadge.text('Stage 1: Normal').attr('class', 'ct-badge-indicator green');
                $statusDischarge.text('Nominal Capacity').attr('class', 'ct-telem-status normal');
                polyColor = '#0284c7';
                polyFill = '#38bdf8';
            } else if (rain < 75) {
                $threatBadge.text('Stage 2: Elevated Runoff').attr('class', 'ct-badge-indicator');
                $statusDischarge.text('Elevated Flow').attr('class', 'ct-telem-status elevated');
                polyColor = '#f59e0b';
                polyFill = '#fbbf24';
            } else {
                $threatBadge.text('Stage 3: Flash Flood Watch').attr('class', 'ct-badge-indicator warning');
                $statusDischarge.text('Critical Watch').attr('class', 'ct-telem-status warning');
                polyColor = '#ef4444';
                polyFill = '#f87171';
            }

            missionCreekPolygon.setStyle({
                color: polyColor,
                fillColor: polyFill,
                fillOpacity: Math.min(0.7, 0.35 + (rain / 200))
            });
        }

        $sliderRain.on('input change', updateHydrologySim);
        $sliderSurge.on('input change', updateHydrologySim);

        // 1-Click: Trigger 100-Year Storm Event
        $('#ct-btn-simulate-flood').on('click', function() {
            $sliderRain.val(98).trigger('input');
            $sliderSurge.val(2.8).trigger('input');

            var log = document.getElementById('ct-mesh-terminal-log');
            if (log) {
                var entry = document.createElement('div');
                entry.style.color = '#f87171';
                entry.innerHTML = '[ALERT] 100-Yr rainfall event triggered (98 mm/hr). Mission Creek culvert alert active.';
                log.insertBefore(entry, log.firstChild);
            }
        });

        // 1-Click: Reset Sim
        $('#ct-btn-reset-sim').on('click', function() {
            $sliderRain.val(22).trigger('input');
            $sliderSurge.val(0.8).trigger('input');
        });

        // 1-Click: Broadcast B-LAN Mesh Ping
        $('#ct-btn-broadcast-ping').on('click', function() {
            var $btn = $(this);
            $btn.prop('disabled', true).text('⚡ Pinging Relays...');

            var log = document.getElementById('ct-mesh-terminal-log');
            var steps = [
                '[TX] Broadcast ping sent from City Hall Primary (735 Anacapa St)...',
                '[ACK] Cottage Hospital Node responded: 16ms (-69 dBm)',
                '[ACK] Harbor Waterfront Patrol responded: 14ms (-64 dBm)',
                '[ACK] Airport Corridor Link responded: 22ms (-74 dBm)',
                '[SUCCESS] All 4 Santa Barbara relays verified operational (100% quorum).'
            ];

            var idx = 0;
            var interval = setInterval(function() {
                if (idx < steps.length) {
                    if (log) {
                        var entry = document.createElement('div');
                        entry.style.color = (idx === steps.length - 1) ? '#34d399' : '#38bdf8';
                        entry.innerHTML = steps[idx];
                        log.insertBefore(entry, log.firstChild);
                    }
                    idx++;
                } else {
                    clearInterval(interval);
                    $btn.prop('disabled', false).text('📡 Broadcast Emergency Mesh Ping');
                }
            }, 400);
        });
    }

    /**
     * Initialize Standalone Map for [civic_twin_map]
     */
    function initSantaBarbaraStandaloneMap() {
        var container = document.getElementById('ct-sb-leaflet-map-standalone');
        if (!container || typeof L === 'undefined') {
            return;
        }

        var lat = (typeof civicTwinSBOptions !== 'undefined' && civicTwinSBOptions.cityLat) ? civicTwinSBOptions.cityLat : 34.42083;
        var lng = (typeof civicTwinSBOptions !== 'undefined' && civicTwinSBOptions.cityLng) ? civicTwinSBOptions.cityLng : -119.69819;

        var standaloneMap = L.map('ct-sb-leaflet-map-standalone', {
            center: [lat, lng],
            zoom: 13
        });

        L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; OpenStreetMap contributors | City of Santa Barbara GIS'
        }).addTo(standaloneMap);

        // Add City Hall Marker
        L.marker([lat, lng]).addTo(standaloneMap)
            .bindPopup('<strong>City of Santa Barbara City Hall</strong><br/>735 Anacapa Street<br/><a href="https://santabarbaraca.gov/" target="_blank">santabarbaraca.gov</a>')
            .openPopup();
    }

    /**
     * Initialize Member Portal Chat / Broadcast
     */
    function initMemberPortalBroadcast() {
        $('#ct-btn-send-mesh-msg').on('click', function() {
            var $input = $('#ct-mesh-input-msg');
            var val = $.trim($input.val());
            if (!val) return;

            var $feed = $('#ct-resident-mesh-feed');
            var timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            var html = '<div class="feed-item" style="border-left-color: #10b981;">' +
                '<strong>[RESIDENT BROADCAST ' + timeStr + ']:</strong> ' + $('<div>').text(val).html() +
                '</div>';

            $feed.prepend(html);
            $input.val('');
        });
    }

})(jQuery);

<?php
/**
 * Civic_Twin Santa Barbara Demo Admin Controller (PHP 8.2+)
 * 
 * Manages admin configurations, Santa Barbara GIS presets, and system connectivity.
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Civic_Twin_SB_Admin {

    public static function init(): void {
        add_action('admin_menu', array(__CLASS__, 'register_admin_menu'));
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('wp_ajax_test_civic_twin_sb_connection', array(__CLASS__, 'ajax_test_connection'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_admin_assets'));
    }

    public static function enqueue_admin_assets(string $hook): void {
        if (strpos($hook, 'civic_twin_sb') === false) {
            return;
        }
        wp_enqueue_style('civic-twin-sb-admin-css', CIVIC_TWIN_SB_URL . 'assets/css/admin-style.css', array(), CIVIC_TWIN_SB_VERSION);
        wp_enqueue_script('civic-twin-sb-admin-js', CIVIC_TWIN_SB_URL . 'assets/js/admin-script.js', array('jquery'), CIVIC_TWIN_SB_VERSION, true);

        wp_localize_script('civic-twin-sb-admin-js', 'ctAdminParams', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('civic_twin_sb_admin_nonce')
        ));
    }

    public static function register_admin_menu(): void {
        add_menu_page(
            __('Santa Barbara Civic Twin', 'civic-twin-sb'),
            __('SB Civic Twin', 'civic-twin-sb'),
            'manage_options',
            'civic_twin_sb_hub',
            array(__CLASS__, 'render_admin_dashboard'),
            'dashicons-location-alt',
            30
        );

        add_submenu_page(
            'civic_twin_sb_hub',
            __('Santa Barbara Settings & Diagnostics', 'civic-twin-sb'),
            __('Settings & GIS', 'civic-twin-sb'),
            'manage_options',
            'civic_twin_sb_hub'
        );

        add_submenu_page(
            'civic_twin_sb_hub',
            __('Santa Barbara Demo Pages', 'civic-twin-sb'),
            __('Demo Pages', 'civic-twin-sb'),
            'manage_options',
            'civic_twin_sb_pages',
            array('Civic_Twin_SB_Member', 'render_creator_page')
        );
    }

    public static function register_settings(): void {
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_city_name');
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_city_website');
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_city_lat');
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_city_lng');
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_city_hall');
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_instance_url');
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_api_key');
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_default_view');
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_theme_accent');
        register_setting('civic_twin_sb_settings_group', 'civic_twin_sb_cache_timeout');
    }

    public static function render_admin_dashboard(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized access.', 'civic-twin-sb'));
        }

        $city_name = (string)get_option('civic_twin_sb_city_name', CIVIC_TWIN_SB_DEFAULT_CITY);
        $city_website = (string)get_option('civic_twin_sb_city_website', CIVIC_TWIN_SB_DEFAULT_WEBSITE);
        $city_lat = (string)get_option('civic_twin_sb_city_lat', (string)CIVIC_TWIN_SB_DEFAULT_LAT);
        $city_lng = (string)get_option('civic_twin_sb_city_lng', (string)CIVIC_TWIN_SB_DEFAULT_LNG);
        $city_hall = (string)get_option('civic_twin_sb_city_hall', CIVIC_TWIN_SB_DEFAULT_ADDRESS);
        $instance_url = (string)get_option('civic_twin_sb_instance_url', 'https://ais-dev-ksgaec2aylr4nxfua3aqki-145896567353.us-east1.run.app');
        $api_key = (string)get_option('civic_twin_sb_api_key', '');
        $default_view = (string)get_option('civic_twin_sb_default_view', 'dashboard');
        $theme_accent = (string)get_option('civic_twin_sb_theme_accent', '#0284c7');
        $cache_timeout = (int)get_option('civic_twin_sb_cache_timeout', 3600);
        ?>
        <div class="wrap civic-twin-admin-wrap">
            <header class="ct-admin-header">
                <div class="ct-branding">
                    <span class="ct-icon-shield">🌊</span>
                    <div>
                        <h1><?php echo esc_html($city_name); ?> — Civic Twin Demo</h1>
                        <p class="ct-subtitle">
                            Angel Sharks v0.1 | Powered by PHP <?php echo esc_html(PHP_VERSION); ?> | Official Portal: 
                            <a href="<?php echo esc_url($city_website); ?>" target="_blank" rel="noopener noreferrer" style="color:#38bdf8; text-decoration:underline;">
                                <?php echo esc_html($city_website); ?> ↗
                            </a>
                        </p>
                    </div>
                </div>
                <div class="ct-badge-group">
                    <span class="ct-version-tag">PHP 8.2+ Verified</span>
                    <span class="ct-version-tag" style="background:#0284c7;">Demo Edition v0.1</span>
                </div>
            </header>

            <!-- Santa Barbara Context Banner -->
            <div class="ct-sb-banner">
                <div class="ct-sb-badge">MUNICIPAL SPATIAL CALIBRATION</div>
                <div class="ct-sb-grid">
                    <div><strong>Coordinates:</strong> <?php echo esc_html($city_lat); ?>° N, <?php echo esc_html($city_lng); ?>° W</div>
                    <div><strong>City Hall:</strong> <?php echo esc_html($city_hall); ?></div>
                    <div><strong>Active Watersheds:</strong> Mission Creek, Arroyo Burro, Santa Ynez Basin</div>
                    <div><strong>Emergency Mesh:</strong> Front Country Coastal Defense & MTD Corridor</div>
                </div>
            </div>

            <div class="ct-grid">
                <!-- Settings Form -->
                <div class="ct-card ct-settings-card">
                    <h2>⚙️ <?php _e('Santa Barbara Twin Configuration', 'civic-twin-sb'); ?></h2>
                    <p class="card-desc"><?php _e('Manage connection parameters, city website references, and UI themes.', 'civic-twin-sb'); ?></p>

                    <form method="post" action="options.php" class="ct-form">
                        <?php settings_fields('civic_twin_sb_settings_group'); ?>
                        <?php do_settings_sections('civic_twin_sb_settings_group'); ?>

                        <div class="ct-form-row">
                            <label for="civic_twin_sb_city_name"><?php _e('Jurisdiction / Entity Name', 'civic-twin-sb'); ?></label>
                            <input type="text" name="civic_twin_sb_city_name" id="civic_twin_sb_city_name" value="<?php echo esc_attr($city_name); ?>" class="regular-text" required />
                        </div>

                        <div class="ct-form-row">
                            <label for="civic_twin_sb_city_website"><?php _e('Official City Website', 'civic-twin-sb'); ?></label>
                            <input type="url" name="civic_twin_sb_city_website" id="civic_twin_sb_city_website" value="<?php echo esc_url($city_website); ?>" class="regular-text" required />
                            <p class="description"><?php _e('Official Santa Barbara municipal site (https://santabarbaraca.gov/).', 'civic-twin-sb'); ?></p>
                        </div>

                        <div class="ct-form-row-grid">
                            <div class="ct-form-row">
                                <label for="civic_twin_sb_city_lat"><?php _e('Latitude', 'civic-twin-sb'); ?></label>
                                <input type="text" name="civic_twin_sb_city_lat" id="civic_twin_sb_city_lat" value="<?php echo esc_attr($city_lat); ?>" />
                            </div>
                            <div class="ct-form-row">
                                <label for="civic_twin_sb_city_lng"><?php _e('Longitude', 'civic-twin-sb'); ?></label>
                                <input type="text" name="civic_twin_sb_city_lng" id="civic_twin_sb_city_lng" value="<?php echo esc_attr($city_lng); ?>" />
                            </div>
                        </div>

                        <div class="ct-form-row">
                            <label for="civic_twin_sb_city_hall"><?php _e('Municipal Headquarters Address', 'civic-twin-sb'); ?></label>
                            <input type="text" name="civic_twin_sb_city_hall" id="civic_twin_sb_city_hall" value="<?php echo esc_attr($city_hall); ?>" class="regular-text" />
                        </div>

                        <div class="ct-form-row">
                            <label for="civic_twin_sb_instance_url"><?php _e('Civic Twin Host Application URL', 'civic-twin-sb'); ?></label>
                            <input type="url" name="civic_twin_sb_instance_url" id="civic_twin_sb_instance_url" value="<?php echo esc_url($instance_url); ?>" class="regular-text" required />
                            <p class="description"><?php _e('The root URL where the Civic Twin interactive simulation is running.', 'civic-twin-sb'); ?></p>
                        </div>

                        <div class="ct-form-row">
                            <label for="civic_twin_sb_theme_accent"><?php _e('Primary Coastal Accent Color', 'civic-twin-sb'); ?></label>
                            <input type="color" name="civic_twin_sb_theme_accent" id="civic_twin_sb_theme_accent" value="<?php echo esc_attr($theme_accent); ?>" />
                            <span class="color-text"><?php echo esc_attr($theme_accent); ?></span>
                        </div>

                        <div class="ct-actions">
                            <?php submit_button(__('Save Santa Barbara Settings', 'civic-twin-sb'), 'primary', 'submit', false); ?>
                            <button type="button" id="btn-test-connection" class="button button-secondary ct-btn-test">
                                🔌 <?php _e('Test Host Connectivity', 'civic-twin-sb'); ?>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Sidebar Diagnostics & Shortcodes -->
                <div class="ct-sidebar-grid">
                    <div class="ct-card ct-status-card">
                        <h3>🔌 <?php _e('Live Host Diagnostics', 'civic-twin-sb'); ?></h3>
                        <div class="status-indicator-box">
                            <div id="ct-connection-light" class="ct-indicator offline"></div>
                            <span id="ct-connection-text"><?php _e('Awaiting Diagnostic Scan...', 'civic-twin-sb'); ?></span>
                        </div>
                        <div class="diagnostics-logs" id="ct-diagnostics-logs">
                            <div class="log-entry system">[SYSTEM] Ready for Santa Barbara host handshake (PHP <?php echo esc_html(PHP_VERSION); ?>).</div>
                        </div>
                    </div>

                    <div class="ct-card ct-quick-links">
                        <h3>📍 <?php _e('Santa Barbara Shortcodes', 'civic-twin-sb'); ?></h3>
                        <p><?php _e('Embed on any WordPress page or post:', 'civic-twin-sb'); ?></p>
                        <ul class="shortcode-list">
                            <li>
                                <code>[civic_twin_dashboard]</code>
                                <span class="tip"><?php _e('Full interactive Santa Barbara Digital Twin matrix.', 'civic-twin-sb'); ?></span>
                            </li>
                            <li>
                                <code>[civic_twin_map]</code>
                                <span class="tip"><?php _e('Spatial Leaflet map calibrated to Santa Barbara coordinates.', 'civic-twin-sb'); ?></span>
                            </li>
                            <li>
                                <code>[civic_twin_member_portal]</code>
                                <span class="tip"><?php _e('Community resident registration & emergency B-LAN mesh.', 'civic-twin-sb'); ?></span>
                            </li>
                            <li>
                                <code>[civic_twin_sb_info]</code>
                                <span class="tip"><?php _e('Official Santa Barbara municipality information card.', 'civic-twin-sb'); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public static function ajax_test_connection(): void {
        check_ajax_referer('civic_twin_sb_admin_nonce', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized permission check', 'civic-twin-sb')));
            return;
        }

        $url = (string)get_option('civic_twin_sb_instance_url', '');
        if (empty($url)) {
            wp_send_json_error(array('message' => __('No host URL configured.', 'civic-twin-sb')));
            return;
        }

        $health_url = esc_url_raw(trailingslashit($url) . 'api/admin/security/status');
        $response = wp_remote_get($health_url, array('timeout' => 8));

        if (is_wp_error($response)) {
            wp_send_json_error(array(
                'message' => __('Host connection failed.', 'civic-twin-sb'),
                'details' => $response->get_error_message()
            ));
            return;
        }

        $code = (int)wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            wp_send_json_error(array(
                'message' => sprintf(__('Host returned HTTP %d.', 'civic-twin-sb'), $code),
                'details' => __('Please verify the host instance URL and security rules.', 'civic-twin-sb')
            ));
            return;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        wp_send_json_success(array(
            'message' => __('Santa Barbara Twin Host Online & Synchronized!', 'civic-twin-sb'),
            'status' => 'online',
            'api_details' => is_array($data) ? $data : array(),
            'timestamp' => current_time('mysql'),
            'php_version' => PHP_VERSION
        ));
    }
}
Civic_Twin_SB_Admin::init();

<?php
/**
 * Civic_Twin Santa Barbara Shortcodes Controller (PHP 8.2+)
 * 
 * Provides responsive shortcode renderers for Santa Barbara GIS, Digital Twin, and Municipal info.
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

class Civic_Twin_SB_Shortcodes {

    public static function init(): void {
        add_shortcode('civic_twin_dashboard', array(__CLASS__, 'render_dashboard'));
        add_shortcode('civic_twin_map', array(__CLASS__, 'render_map'));
        add_shortcode('civic_twin_member_portal', array(__CLASS__, 'render_member_portal'));
        add_shortcode('civic_twin_sb_info', array(__CLASS__, 'render_sb_info'));
    }

    /**
     * [civic_twin_dashboard]
     */
    public static function render_dashboard(array|string $atts): string {
        $atts = shortcode_atts(array(
            'height' => '750px',
            'border_radius' => '1.5rem',
            'theme' => 'light'
        ), (array)$atts, 'civic_twin_dashboard');

        $instance_url = (string)get_option('civic_twin_sb_instance_url', '');
        if (empty($instance_url)) {
            return '<div class="ct-error-notice">' . esc_html__('Notice: Civic Twin Host URL not configured in WordPress Admin > SB Civic Twin.', 'civic-twin-sb') . '</div>';
        }

        $city_name = (string)get_option('civic_twin_sb_city_name', CIVIC_TWIN_SB_DEFAULT_CITY);
        $city_website = (string)get_option('civic_twin_sb_city_website', CIVIC_TWIN_SB_DEFAULT_WEBSITE);
        $city_lat = (string)get_option('civic_twin_sb_city_lat', (string)CIVIC_TWIN_SB_DEFAULT_LAT);
        $city_lng = (string)get_option('civic_twin_sb_city_lng', (string)CIVIC_TWIN_SB_DEFAULT_LNG);
        $accent_color = sanitize_hex_color((string)get_option('civic_twin_sb_theme_accent', '#0284c7'));

        // Construct Santa Barbara targeted URL
        $query_args = array(
            'view' => 'public',
            'city' => rawurlencode($city_name),
            'lat' => $city_lat,
            'lng' => $city_lng,
            'website' => rawurlencode($city_website)
        );
        $iframe_url = add_query_arg($query_args, trailingslashit($instance_url));

        ob_start();
        ?>
        <div class="ct-public-container" style="--ct-accent-color: <?php echo esc_attr($accent_color); ?>;">
            <div class="ct-frame-header">
                <div class="ct-frame-brand">
                    <span class="ct-indicator active"></span>
                    <span><?php echo esc_html(strtoupper($city_name)); ?> — DIGITAL TWIN DEMO MATRIX</span>
                </div>
                <div class="ct-frame-actions">
                    <a href="<?php echo esc_url($city_website); ?>" target="_blank" rel="noopener noreferrer" class="ct-btn-header-link" style="margin-right:8px;">
                        🏛️ <?php _e('City Website', 'civic-twin-sb'); ?>
                    </a>
                    <a href="<?php echo esc_url($iframe_url); ?>" target="_blank" rel="noopener noreferrer" class="ct-btn-header-link">
                        <?php _e('Expand Shard', 'civic-twin-sb'); ?> ↗
                    </a>
                </div>
            </div>
            <div class="ct-iframe-wrapper" style="height: <?php echo esc_attr($atts['height']); ?>; border-radius: <?php echo esc_attr($atts['border_radius']); ?>;">
                <div class="ct-loader-overlay">
                    <div class="ct-spinner"></div>
                    <p><?php _e('Streaming Santa Barbara GIS & Hydrology Twin...', 'civic-twin-sb'); ?></p>
                </div>
                <iframe 
                    src="<?php echo esc_url($iframe_url); ?>" 
                    class="ct-iframe" 
                    id="civic-twin-sb-main-iframe"
                    allow="geolocation; camera; microphone"
                    onload="var el=this.previousElementSibling; if(el) el.style.display='none';">
                </iframe>
            </div>
        </div>
        <?php
        return (string)ob_get_clean();
    }

    /**
     * [civic_twin_map]
     */
    public static function render_map(array|string $atts): string {
        $atts = shortcode_atts(array(
            'height' => '600px',
            'border_radius' => '1.5rem',
        ), (array)$atts, 'civic_twin_map');

        $instance_url = (string)get_option('civic_twin_sb_instance_url', '');
        if (empty($instance_url)) {
            return '<div class="ct-error-notice">' . esc_html__('Notice: Civic Twin Host URL not configured.', 'civic-twin-sb') . '</div>';
        }

        $city_lat = (string)get_option('civic_twin_sb_city_lat', (string)CIVIC_TWIN_SB_DEFAULT_LAT);
        $city_lng = (string)get_option('civic_twin_sb_city_lng', (string)CIVIC_TWIN_SB_DEFAULT_LNG);
        $accent_color = sanitize_hex_color((string)get_option('civic_twin_sb_theme_accent', '#0284c7'));

        $query_args = array(
            'view' => 'public',
            'focus' => 'map',
            'lat' => $city_lat,
            'lng' => $city_lng
        );
        $iframe_url = add_query_arg($query_args, trailingslashit($instance_url));

        ob_start();
        ?>
        <div class="ct-public-container" style="--ct-accent-color: <?php echo esc_attr($accent_color); ?>;">
            <div class="ct-iframe-wrapper" style="height: <?php echo esc_attr($atts['height']); ?>; border-radius: <?php echo esc_attr($atts['border_radius']); ?>;">
                <iframe 
                    src="<?php echo esc_url($iframe_url); ?>" 
                    class="ct-iframe" 
                    allow="geolocation">
                </iframe>
            </div>
        </div>
        <?php
        return (string)ob_get_clean();
    }

    /**
     * [civic_twin_member_portal]
     */
    public static function render_member_portal(array|string $atts): string {
        $atts = shortcode_atts(array(
            'height' => '650px',
            'border_radius' => '1.5rem',
        ), (array)$atts, 'civic_twin_member_portal');

        $instance_url = (string)get_option('civic_twin_sb_instance_url', '');
        if (empty($instance_url)) {
            return '<div class="ct-error-notice">' . esc_html__('Notice: Civic Twin Host URL not configured.', 'civic-twin-sb') . '</div>';
        }

        $accent_color = sanitize_hex_color((string)get_option('civic_twin_sb_theme_accent', '#0284c7'));
        $iframe_url = add_query_arg(array('view' => 'public', 'focus' => 'mesh'), trailingslashit($instance_url));

        ob_start();
        ?>
        <div class="ct-public-container" style="--ct-accent-color: <?php echo esc_attr($accent_color); ?>;">
            <div class="ct-iframe-wrapper" style="height: <?php echo esc_attr($atts['height']); ?>; border-radius: <?php echo esc_attr($atts['border_radius']); ?>;">
                <iframe 
                    src="<?php echo esc_url($iframe_url); ?>" 
                    class="ct-iframe">
                </iframe>
            </div>
        </div>
        <?php
        return (string)ob_get_clean();
    }

    /**
     * [civic_twin_sb_info]
     * Displays a municipal info card connecting to https://santabarbaraca.gov/
     */
    public static function render_sb_info(array|string $atts = array()): string {
        $city_name = (string)get_option('civic_twin_sb_city_name', CIVIC_TWIN_SB_DEFAULT_CITY);
        $city_website = (string)get_option('civic_twin_sb_city_website', CIVIC_TWIN_SB_DEFAULT_WEBSITE);
        $city_hall = (string)get_option('civic_twin_sb_city_hall', CIVIC_TWIN_SB_DEFAULT_ADDRESS);
        $city_lat = (string)get_option('civic_twin_sb_city_lat', (string)CIVIC_TWIN_SB_DEFAULT_LAT);
        $city_lng = (string)get_option('civic_twin_sb_city_lng', (string)CIVIC_TWIN_SB_DEFAULT_LNG);

        ob_start();
        ?>
        <div class="ct-sb-info-card">
            <div class="ct-sb-info-header">
                <div class="ct-sb-icon">🏛️</div>
                <div>
                    <h3><?php echo esc_html($city_name); ?> — Civic Twin Demo Information</h3>
                    <p><?php _e('NIST Urban Resilience & B-LAN Mesh Simulation Calibration', 'civic-twin-sb'); ?></p>
                </div>
            </div>
            <div class="ct-sb-info-body">
                <div class="ct-sb-info-col">
                    <span class="label"><?php _e('Official Municipal Website:', 'civic-twin-sb'); ?></span>
                    <a href="<?php echo esc_url($city_website); ?>" target="_blank" rel="noopener noreferrer" class="link">
                        <?php echo esc_html($city_website); ?> ↗
                    </a>
                </div>
                <div class="ct-sb-info-col">
                    <span class="label"><?php _e('City Hall Headquarters:', 'civic-twin-sb'); ?></span>
                    <span class="val"><?php echo esc_html($city_hall); ?></span>
                </div>
                <div class="ct-sb-info-col">
                    <span class="label"><?php _e('Geospatial Centroid:', 'civic-twin-sb'); ?></span>
                    <span class="val"><?php echo esc_html($city_lat); ?>° N, <?php echo esc_html($city_lng); ?>° W</span>
                </div>
                <div class="ct-sb-info-col">
                    <span class="label"><?php _e('Key GIS Layers:', 'civic-twin-sb'); ?></span>
                    <span class="val">Mission Creek Basin, Harbor Marine Zone, MTD Transit Network</span>
                </div>
            </div>
            <div class="ct-sb-info-footer">
                <span>Angel Sharks Civic Twin Demonstration Edition | Designed for WordPress on PHP 8.2+</span>
            </div>
        </div>
        <?php
        return (string)ob_get_clean();
    }
}
Civic_Twin_SB_Shortcodes::init();

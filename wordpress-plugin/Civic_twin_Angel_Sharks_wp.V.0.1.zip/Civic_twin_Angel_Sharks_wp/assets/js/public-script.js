/**
 * Civic_Twin Santa Barbara Public Script
 */

jQuery(document).ready(function($) {
    // Handle iframe auto-fitting or fullscreen expansion if needed
    $('.ct-btn-header-link').on('click', function() {
        // Link handling
    });
});
